const fs = require("fs");
const path = require("path");

const originPath = path.join(__dirname, "../FileOrigin");
const endPath = path.join(__dirname, "../FileEnd");
