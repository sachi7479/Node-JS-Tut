// import a module
// const fs  = require('fs') for importing all methods
const fs  = require('fs').writeFileSync;
console.log("how are you?")
fs.writeFileSync("hello.txt","how are you?")

// __filename