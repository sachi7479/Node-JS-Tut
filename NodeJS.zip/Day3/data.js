const data = [
    {name:'sachin singh',email:'sacin@test.com'},
    {name:'SAM',email:'sam@test.com'},
    {name:'peter',email:'peter@test.com'}
]
module.exports = data;