const colors = require('colors');
console.log("Package.json".bgRed)